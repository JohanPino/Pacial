﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Corte1POO {
    class ItemEvalua {
        int tipo; //Tipo de dato que evalúa
        string cadena; //Cadena generada al azar
        bool valoracion; //¿Válido o inválido? 
        bool estudiante; //Lo que dice el trabajo del estudiante

        public ItemEvalua(int tipo, string cadena, bool valoracion, bool estudiante) {
            this.tipo = tipo;
            this.cadena = cadena;
            this.valoracion = valoracion;
            this.estudiante = estudiante;
        }

        public int Evaluando() {
            if (valoracion != estudiante) return 0;
            return 1;
        }

        public void Imprime() {
            switch (tipo) {
                case 0: Console.Write("Paréntesis "); break;
                case 1: Console.Write("Mala palabra "); break;
                case 2: Console.Write("Número largo "); break;
                case 3: Console.Write("Mala expresión "); break;
            }
            Console.Write("[" + cadena + "]");
            Console.WriteLine("\t\t" + valoracion + "\t" + estudiante);
        }
    }
}
