﻿/* Universidad Libre Cali
 * Facultad de Ingeniería
 * Cátedra de Programación Orientada a Objetos
 * Corte 1 (2019-2) */

using System;
using System.Collections;
using System.Linq;

namespace Corte1POO {
    //==============================
    //¡OJO! No modifique este código
    //==============================

    class Program {
        static Random azar; //Generador de números aleatorios

        //Declara la lista que almacenará las evaluaciones
        static ArrayList Evaluacion;

        //La clase que el estudiante va a escribir
        static Validador objValida;

        static void Main(string[] args) {

            //Inicializa el generador de números aleatorios
            azar = new Random();

            //Inicializa la lista
            Evaluacion = new ArrayList();

            //Inicializa el validador
            objValida = new Validador();

            //Pruebas a realizar
            int TotalPruebas = 100000;

            for (int prueba=1; prueba<=TotalPruebas; prueba++){
                EvaluaParentesis();
                EvaluaMalaPalabra();
                EvaluaNumerosLargos();
                EvaluaExpresionEsp();
            }

            //Califica al estudiante
            int acumula = 0;
            for (int cont = 0; cont < Evaluacion.Count; cont++) {
                acumula += (Evaluacion[cont] as ItemEvalua).Evaluando();
                (Evaluacion[cont] as ItemEvalua).Imprime();
            }

            double calificacion = (double) acumula * 5.0 / (TotalPruebas*4.0);
            Console.WriteLine("Resultado: " + calificacion);
            Console.ReadLine();
        }

        //Prueba a validar paréntesis < > {  } [ ] ( )
        static void EvaluaParentesis() { 
            string cad = "";
            bool evalua = true;
            if (azar.NextDouble() < 0.5) {
                cad = ParentesisInvalido();
                evalua = false;
            } else {
                cad = ParentesisValido();
                evalua = true;
            }
            Evaluacion.Add(new ItemEvalua(0, cad, evalua, objValida.EvaluaParentesis(cad)));
        }

        static string ParentesisValido() {
            string[] Reemplazo = { "(a)", "<a>", "{a}", "[a]", "(A)", "<A>", "{A}", "[A]", "(B)", "<B>", "{B}", "[B]", "(C)", "<C>", "{C}", "[C]"};
            string cad = "ABC";
            int num;
            do
            {
                num = azar.Next(0, Reemplazo.Length);
                cad = cad.Replace("A", Reemplazo[num]);
                cad = cad.Replace("B", Reemplazo[num]);
                cad = cad.Replace("C", Reemplazo[num]);
                if (cad.Length > 300) cad = "ABC";
            } while (cad.Contains('A') || cad.Contains('B') || cad.Contains('C'));
            return cad;
        }

        static string ParentesisInvalido() {
            string[] Reemplazo = { "(a>", "<a}", "{a]", "[a)", "(A)", "<A>", "{A}", "[A]", "(B)", "<B>", "{B}", "[B]", "(C)", "<C>", "{C}", "[C]" };
            string cad = "ABC";
            int num;
            do
            {
                num = azar.Next(0, Reemplazo.Length);
                cad = cad.Replace("A", Reemplazo[num]);
                cad = cad.Replace("B", Reemplazo[num]);
                cad = cad.Replace("C", Reemplazo[num]);
                if (cad.Length > 300) cad = "ABC";
            } while (cad.Contains('A') || cad.Contains('B') || cad.Contains('C'));
            return cad;
        }

        //Prueba a validar MalaPalabra
        static void EvaluaMalaPalabra() {
            string cad = "";
            bool evalua = true;
            if (azar.NextDouble() < 0.5) {
                cad = MalaPalabraInvalida();
                evalua = false;
            }
            else {
                cad = MalaPalabraValida();
                evalua = true;
            }
            Evaluacion.Add(new ItemEvalua(1, cad, evalua, objValida.EvaluaMalaPalabra(cad)));
        }

        static string MalaPalabraValida() {
            string[] Reemplazo = { " ", ".", "!", " A", ".A", "!A", " B", ".B", "!B", " C", ".C", "!C"};
            string cad = "aAbBcCd";
            int num;
            do
            {
                num = azar.Next(0, Reemplazo.Length);
                cad = cad.Replace("A", Reemplazo[num]);
                cad = cad.Replace("B", Reemplazo[num]);
                cad = cad.Replace("C", Reemplazo[num]);
                if (cad.Length > 300) cad = "ABC";
            } while (cad.Contains('A') || cad.Contains('B') || cad.Contains('C'));
            return cad;
        }

        static string MalaPalabraInvalida() {
            string[] Reemplazo = { "ad", "bb", "cc", " A", ".A", "!A", " B", ".B", "!B", " C", ".C", "!C" };
            string cad = "aAbBcCd";
            int num;
            do
            {
                num = azar.Next(0, Reemplazo.Length);
                cad = cad.Replace("A", Reemplazo[num]);
                cad = cad.Replace("B", Reemplazo[num]);
                cad = cad.Replace("C", Reemplazo[num]);
                if (cad.Length > 300) cad = "ABC";
            } while (cad.Contains('A') || cad.Contains('B') || cad.Contains('C'));
            return cad;
        }

        //Prueba Números largos
        static void EvaluaNumerosLargos() {
            string cad = "";
            bool evalua = true;
            if (azar.NextDouble() < 0.5) {
                cad = NumeroInvalido();
                evalua = false;
            }
            else {
                cad = NumeroValido();
                evalua = true;
            }
            Evaluacion.Add(new ItemEvalua(2, cad, evalua, objValida.EvaluaNumeroLargo(cad)));
        }

        static string NumeroValido() {
            string cad = "";
            int parteEntera = azar.Next(100, 10000);
            int parteDecimal = azar.Next(100, 10000);
            cad = parteEntera.ToString() + "." + parteDecimal.ToString();
            return cad;
        }

        static string NumeroInvalido() {
            int parteEntera = azar.Next(100, 100000);
            int parteDecimal = azar.Next(100, 100000);
            string cad = "";

            switch (azar.Next(5))
            {
                case 0: return NumeroValido() + NumeroValido();
                case 1: return parteEntera.ToString() + "k." + parteDecimal.ToString();
                case 2: return parteEntera.ToString() + "." + parteDecimal.ToString() + "ñ";
                case 3: return parteEntera.ToString() + ".r" + parteDecimal.ToString();
                case 4: cad = "";
                    for (int cont = 1; cont <= 20; cont++) cad += azar.Next(1, 10).ToString();
                    return cad;
            }
            return "abc";
        }

        //Prueba si una expresión es válida
        static void EvaluaExpresionEsp() {
            string cad = "";
            bool evalua = true;
            if (azar.NextDouble() < 0.5) {
                cad = EvaluaExpresionEspInvalido();
                evalua = false;
            }
            else {
                cad = EvaluaExpresionEspValido();
                evalua = true;
            }
            Evaluacion.Add(new ItemEvalua(3, cad, evalua, objValida.EvaluaExpresionEspanol(cad)));
        }

        static string EvaluaExpresionEspValido() {
            string[] Reemplazo = { "¡OK!", "¿OK?", "A¡OK!", "A¿OK?", "¡OK!B", "¿OK?B" };
            string cad = "AB";
            int num;
            do
            {
                num = azar.Next(0, Reemplazo.Length);
                cad = cad.Replace("A", Reemplazo[num]);
                cad = cad.Replace("B", Reemplazo[num]);
                if (cad.Length > 300) cad = "AB";
            } while (cad.Contains('A') || cad.Contains('B'));
            return cad;
        }

        static string EvaluaExpresionEspInvalido() {
            string[] Reemplazo = { "¡OK¡", "!OK!", "?OK?", "¿OK¿", "A¡OK?", "A¡OK¿", "¿OK¡B", "¿OK!B", "¿¿OK??A", "¡¡OK!!B" };
            string cad = "AB";
            int num;
            do
            {
                num = azar.Next(0, Reemplazo.Length);
                cad = cad.Replace("A", Reemplazo[num]);
                cad = cad.Replace("B", Reemplazo[num]);
                if (cad.Length > 300) cad = "AB";
            } while (cad.Contains('A') || cad.Contains('B'));
            return cad;
        }

    }
}
