﻿/*  Universidad Libre Cali
 *  Facultad de Ingeniería
 *  Programa de Ingeniería de Sistemas
 *  2019-2
 *  
 *  Nombre: xxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxxxxxx  Código: xxxxxxxxxx
 *  Nombre: xxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxxxxxx  Código: xxxxxxxxxx
 * */

namespace Corte1POO {
    class Validador {

        /* Evalúa que estos símbolos están balanceados, es decir, mismo número que abre
         * mismo número que cierra:
         * ( ) < > { } [ ]
         * Correcto:  ([abc def])
         *            <<def>ghi>
         *            [{qwertyuiop asdfghjkl }]
         *            zxcv[{aaaa]}
         *            qased < ffg{ jjk[ iop (]hjk>oop}eer)
         *            
         * Incorrecto:  ((asd)
         *              <qwed<rtyh{dfgh>>io
         *              <<}
         *              {a{z]d]f
         *              
         * Evalúa que así existan el mismo número que abre y cierra, exista correspondencia
         * por cada simbolo de apertura tiene correcto cierre
         * Correcto:   (abc)
         *             {(abc)}
         *             <{[(dfg bnm)]}>
         *             w<e{r[t(ydufg bnm)i]}pq>
         *             <a>{b}[c](d)
         *             
         * Incorrecto:
         *             )a(
         *             >b)c(d<
         *             }{)(][
         *             [a}{b]
         *             ([(asd]))
         * */
        public bool EvaluaParentesis(string cadena) {
            //Retorna true si los símbolos están bien balanceados y hay correspondencia
            return true;
        }

        /* Un truco en varios foros para insultar y evitar la censura es poner
         * símbolos, espacios en las palabras, intercalar mayúsculas y minúsculas, quitar tildes
         * Ejemplo: t.onto, tOnTO,  t o n t o */
        public bool EvaluaMalaPalabra(string cadena) {
            /* Retorna true si encuentra la siguiente palabra en un texto así la transformen:
             * abcd
             */
            return true;
        }

        /* Valida si un número pasa de 15 digitos antes del punto decimal 
         * o tiene letras o símbolos
         * Correcto: 15.7
         *           -3.456
         *           7123.67
         * Incorrecto: 1234567890123456.4
         *             1234.6a899
         *             1b56.78
         *             3#2223.556
         *             77.1234%
         */
        public bool EvaluaNumeroLargo(string cadena) {
            /* Retorna true si el número es válido */
            return true;
        }

        /* En nuestro idioma el español, si hay una pregunta se encierra entre ¿ ?
         * o de admiración ¡! . ¡OJO! No pueden anidarse.
         * Correcto: ¿Estás seguro?
         *           ¡Increíble!
         *           ¿Qué? ¡Es imposible!
         *           ¡Haz algo ahora! ¿Procastinar? ¡No!
         *           
         * Incorrecto: Cómo estás?
         *             Te quiero!
         *             ¿Por qué ¡Hiciste eso!?
         *             ¡¿Estás loco?!
         *             ?por qué¿
         *             ¿¿Es cierto??
         */
        public bool EvaluaExpresionEspanol(string cadena) {
            /* Retorna true si la expresión es correcta */
            return true;
        }
    }
}
